# Pegboard

A drag-and-drop task board styled like a physical workshop pegboard —
tasks are paper cards pinned to three sections of perforated board.
No backend, no build step, no account. Open `index.html` and start pinning.

**[Live demo →](#)** *(enable GitHub Pages after pushing — see below)*

## Why this project

Most "todo app" portfolio pieces are functionally identical and visually
interchangeable. This one is the same idea (a kanban board) built with an
actual point of view: a tactile, physical metaphor carried through the
color palette, the pushpin markers, the slight tilt on each card, and the
routed rails between columns. It's meant to demonstrate:

- Vanilla JS state management (no framework) with `localStorage` persistence
- Native HTML5 drag-and-drop, built from scratch
- Deliberate visual design: a custom token system (color, type, layout)
  rather than default component styling
- Accessible details: visible focus states, `prefers-reduced-motion`
  support, keyboard-friendly editing

## Features

- **Three columns** — To do, In progress, Done
- **Drag and drop** cards between columns
- **Click a card** to edit its text inline
- **Priority** per card (low / med / high), color-coded
- **Add / delete** cards
- **Clear done** button to sweep finished cards in one click
- Everything persists in the browser via `localStorage` — refresh-safe,
  no server required

## Tech

Plain HTML, CSS, and JavaScript. Fonts are loaded from Google Fonts
(Space Grotesk, Inter, JetBrains Mono); everything else is dependency-free.

```
pegboard/
├── index.html      # markup + a <template> for cards
├── styles.css       # design tokens and layout
├── script.js         # state, rendering, drag-and-drop
└── README.md
```

## Running locally

No build step needed — just open the file:

```bash
git clone https://github.com/<your-username>/pegboard.git
cd pegboard
open index.html   # or just double-click it
```

Or serve it locally if you prefer:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploying to GitHub Pages

1. Push this repo to GitHub (see below).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`.
4. Your board will be live at `https://<your-username>.github.io/pegboard/`
   within a minute or two.

## Ideas for extending it

- Swap `localStorage` for a real backend (Supabase, Firebase, or a small
  Express API) to sync across devices
- Add columns dynamically instead of the fixed three
- Add due dates and a "due soon" pin color
- Export/import the board as JSON

## License

MIT — see [LICENSE](LICENSE).
