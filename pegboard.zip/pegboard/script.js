// Pegboard — a tiny, dependency-free kanban board.
// State lives in localStorage under STORAGE_KEY; everything else is
// derived from it on each render. No framework, no build step.

const STORAGE_KEY = "pegboard:cards:v1";

const COLUMNS = [
  { key: "todo", label: "To do" },
  { key: "progress", label: "In progress" },
  { key: "done", label: "Done" },
];

const board = document.getElementById("board");
const cardTemplate = document.getElementById("card-template");

/** @type {{id:string, text:string, column:string, priority:string}[]} */
let cards = loadCards();

function loadCards() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return seedCards();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : seedCards();
  } catch {
    return seedCards();
  }
}

function seedCards() {
  return [
    { id: makeId(), text: "Drag me to another column", column: "todo", priority: "med" },
    { id: makeId(), text: "Click a card to edit its text", column: "todo", priority: "low" },
    { id: makeId(), text: "Set a priority from the dropdown", column: "progress", priority: "high" },
    { id: makeId(), text: "Everything saves to your browser automatically", column: "done", priority: "low" },
  ];
}

function saveCards() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cards));
}

function makeId() {
  return Math.random().toString(36).slice(2, 7);
}

function render() {
  board.innerHTML = "";

  COLUMNS.forEach((col) => {
    const colCards = cards.filter((c) => c.column === col.key);

    const section = document.createElement("section");
    section.className = "column";
    section.dataset.key = col.key;
    section.setAttribute("aria-label", col.label);

    const header = document.createElement("div");
    header.className = "column-header";
    header.innerHTML = `<h2>${col.label}</h2><span class="column-count mono">${colCards.length}</span>`;
    section.appendChild(header);

    const list = document.createElement("div");
    list.className = "card-list";
    list.dataset.key = col.key;

    if (colCards.length === 0) {
      const hint = document.createElement("p");
      hint.className = "empty-hint";
      hint.textContent = "nothing pinned here";
      list.appendChild(hint);
    } else {
      colCards.forEach((card) => list.appendChild(renderCard(card)));
    }

    attachListDropZone(list);
    section.appendChild(list);
    section.appendChild(renderAddRow(col.key));
    board.appendChild(section);
  });
}

function renderCard(card) {
  const node = cardTemplate.content.firstElementChild.cloneNode(true);
  node.dataset.id = card.id;
  node.dataset.priority = card.priority;
  node.style.setProperty("--tilt", `${((hashCode(card.id) % 5) - 2)}deg`);

  const text = node.querySelector(".card-text");
  text.textContent = card.text;
  text.addEventListener("click", () => startEditing(node, text, card));

  const del = node.querySelector(".card-delete");
  del.addEventListener("click", (e) => {
    e.stopPropagation();
    cards = cards.filter((c) => c.id !== card.id);
    saveCards();
    render();
  });

  const priority = node.querySelector(".card-priority");
  priority.value = card.priority;
  priority.addEventListener("click", (e) => e.stopPropagation());
  priority.addEventListener("change", () => {
    card.priority = priority.value;
    node.dataset.priority = priority.value;
    saveCards();
  });

  node.querySelector(".card-id").textContent = `#${card.id}`;

  node.addEventListener("dragstart", () => {
    node.classList.add("dragging");
  });
  node.addEventListener("dragend", () => {
    node.classList.remove("dragging");
  });

  return node;
}

function startEditing(node, textEl, card) {
  textEl.contentEditable = "true";
  textEl.focus();
  placeCaretAtEnd(textEl);

  const commit = () => {
    textEl.contentEditable = "false";
    const value = textEl.textContent.trim() || card.text;
    textEl.textContent = value;
    card.text = value;
    saveCards();
  };

  textEl.addEventListener("blur", commit, { once: true });
  textEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      textEl.blur();
    }
    if (e.key === "Escape") {
      textEl.textContent = card.text;
      textEl.blur();
    }
  });
}

function placeCaretAtEnd(el) {
  const range = document.createRange();
  range.selectNodeContents(el);
  range.collapse(false);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);
}

function renderAddRow(columnKey) {
  const wrap = document.createElement("div");
  wrap.className = "add-row";

  const button = document.createElement("button");
  button.className = "btn-add";
  button.type = "button";
  button.textContent = "+ pin a task";

  const form = document.createElement("div");
  form.className = "add-form";

  const textarea = document.createElement("textarea");
  textarea.placeholder = "What needs doing?";
  textarea.rows = 2;

  const actions = document.createElement("div");
  actions.className = "add-form-actions";

  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.textContent = "cancel";

  const submit = document.createElement("button");
  submit.type = "button";
  submit.className = "primary";
  submit.textContent = "pin it";

  actions.append(cancel, submit);
  form.append(textarea, actions);
  wrap.append(button, form);

  const openForm = () => {
    button.style.display = "none";
    form.classList.add("open");
    textarea.focus();
  };
  const closeForm = () => {
    button.style.display = "";
    form.classList.remove("open");
    textarea.value = "";
  };

  button.addEventListener("click", openForm);
  cancel.addEventListener("click", closeForm);

  const addCard = () => {
    const text = textarea.value.trim();
    if (!text) return closeForm();
    cards.push({ id: makeId(), text, column: columnKey, priority: "med" });
    saveCards();
    render();
  };

  submit.addEventListener("click", addCard);
  textarea.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      addCard();
    }
    if (e.key === "Escape") closeForm();
  });

  return wrap;
}

function attachListDropZone(list) {
  list.addEventListener("dragover", (e) => {
    e.preventDefault();
    list.classList.add("drag-over");
  });
  list.addEventListener("dragleave", () => list.classList.remove("drag-over"));
  list.addEventListener("drop", (e) => {
    e.preventDefault();
    list.classList.remove("drag-over");
    const dragging = board.querySelector(".card.dragging");
    if (!dragging) return;
    const card = cards.find((c) => c.id === dragging.dataset.id);
    if (!card) return;
    card.column = list.dataset.key;
    saveCards();
    render();
  });
}

function hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

document.getElementById("clear-done").addEventListener("click", () => {
  cards = cards.filter((c) => c.column !== "done");
  saveCards();
  render();
});

document.getElementById("today").textContent = new Date().toLocaleDateString(undefined, {
  weekday: "short",
  month: "short",
  day: "numeric",
});

render();
